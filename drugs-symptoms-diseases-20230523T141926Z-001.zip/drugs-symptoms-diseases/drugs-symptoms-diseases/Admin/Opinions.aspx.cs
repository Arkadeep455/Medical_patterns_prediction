﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace drugs_symptoms_diseases.Admin
{
    public partial class Opinions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["AdminId"] == null)
            {
                Session.Abandon();
                Response.Redirect("~/UserLogin.aspx");
            }
            else
            {
                if (!this.IsPostBack)
                {
                   LoadDrugs();
                }

                LoadOpinions();
            }
        }

        //function to load all drugs
        private void LoadDrugs()
        {
            DataTable tab = new DataTable();
            BLL obj = new BLL();

            tab = obj.GetKeywordsByType("Drug");

            if (tab.Rows.Count > 0)
            {
                dropdownlistDrug.Items.Clear();

                dropdownlistDrug.DataSource = tab;
                dropdownlistDrug.DataTextField = "Keyword";
                dropdownlistDrug.DataValueField = "KeywordId";

                dropdownlistDrug.DataBind();

                dropdownlistDrug.Items.Insert(0, "All");

            }
            else
            {
                dropdownlistDrug.Items.Insert(0, "- Input Drugs-");

            }
        }
              

        //function to load all opinions
        private void LoadOpinions()
        {
            try
            {
                DataTable tab = new DataTable();
                BLL obj = new BLL();

                int serialNo = 1;

                if (dropdownlistDrug.SelectedIndex > 0)
                {
                    tab = obj.GetOpinionsByDrug(int.Parse(dropdownlistDrug.SelectedValue));

                }
                else
                {
                    tab = obj.GetAllOpinions();
                }

                if (tab.Rows.Count > 0)
                {
                    tableOpinions.Rows.Clear();

                    tableOpinions.BorderStyle = BorderStyle.Double;
                    tableOpinions.GridLines = GridLines.Both;
                    tableOpinions.BorderColor = System.Drawing.Color.Black;

                    TableRow mainrow = new TableRow();
                    mainrow.HorizontalAlign = HorizontalAlign.Left;
                    mainrow.Height = 30;
                    mainrow.ForeColor = System.Drawing.Color.WhiteSmoke;
                    mainrow.Font.Bold = true;
                    mainrow.BackColor = System.Drawing.Color.DarkGreen;

                    TableCell cell1 = new TableCell();
                    cell1.Text = "<b>SL No</b>";
                    mainrow.Controls.Add(cell1);

                    TableCell cell11 = new TableCell();
                    cell11.Text = "<b>Medical Prac</b>";
                    mainrow.Controls.Add(cell11);


                    TableCell cell2 = new TableCell();
                    cell2.Text = "<b>Patient Name</b>";
                    mainrow.Controls.Add(cell2);

                    TableCell cell6 = new TableCell();
                    cell6.Text = "<b>Opinion</b>";
                    mainrow.Controls.Add(cell6);

                    TableCell cell7 = new TableCell();
                    cell7.Text = "<b>Date</b>";
                    mainrow.Controls.Add(cell7);

                    TableCell cell8 = new TableCell();
                    cell8.Text = "<b>Rating</b>";
                    mainrow.Controls.Add(cell8);

                    if (dropdownlistDrug.SelectedIndex > 0)
                    {
                        TableCell cell10 = new TableCell();
                        cell10.Text = "<b>Delete</b>";
                        mainrow.Controls.Add(cell10);
                    }

                    tableOpinions.Controls.Add(mainrow);

                    for (int i = 0; i < tab.Rows.Count; i++)
                    {
                        TableRow row = new TableRow();
                        row.HorizontalAlign = HorizontalAlign.Left;
                        row.Height = 75;

                        TableCell cellSerialNo = new TableCell();
                        cellSerialNo.Width = 50;
                        cellSerialNo.Text = serialNo + i + ".";
                        row.Controls.Add(cellSerialNo);

                        TableCell cellMP = new TableCell();
                        cellMP.Width = 150;
                        cellMP.Text = tab.Rows[i]["LoginId"].ToString();
                        row.Controls.Add(cellMP);                                              

                        TableCell cellName = new TableCell();
                        cellName.Width = 150;

                        string gender = null;
                        if (tab.Rows[i]["Gender"].ToString().Equals("True"))
                        {
                            gender = "Male";
                        }
                        else
                        {
                            gender = "Female";
                        }

                        cellName.Text = "<a href='#'>" + tab.Rows[i]["Name"].ToString() + "<span>Gender : " + gender + ".</br>Age : " + tab.Rows[i]["Age"].ToString() + ".</br>Address : " + tab.Rows[i]["Address"].ToString() + "</span></a>";
                        row.Controls.Add(cellName);

                        TableCell cellOpinion = new TableCell();
                        cellOpinion.Width = 700;
                        cellOpinion.Text = tab.Rows[i]["Opinion"].ToString();
                        row.Controls.Add(cellOpinion);

                        TableCell cellDate = new TableCell();
                        cellDate.Width = 100;
                        cellDate.Text = tab.Rows[i]["PostedDate"].ToString();
                        row.Controls.Add(cellDate);

                        TableCell cellRating = new TableCell();
                        cellRating.Width = 100;
                        cellRating.Text = tab.Rows[i]["Rating"].ToString();
                        row.Controls.Add(cellRating);

                        if (dropdownlistDrug.SelectedIndex > 0)
                        {
                            TableCell cell_delete = new TableCell();
                            cell_delete.Width = 50;
                            LinkButton lbtn_delete = new LinkButton();
                            lbtn_delete.ForeColor = System.Drawing.Color.Red;
                            lbtn_delete.Text = "Delete";

                            lbtn_delete.ID = "Delete~" + tab.Rows[i]["OpinionId"].ToString();
                            lbtn_delete.OnClientClick = "return confirm('Are you sure want to delete this Opinion?')";
                            lbtn_delete.Click += new EventHandler(lbtn_delete_Click);
                            cell_delete.Controls.Add(lbtn_delete);
                            row.Controls.Add(cell_delete);
                        }

                        tableOpinions.Controls.Add(row);
                    }
                }
                else
                {
                    tableOpinions.Rows.Clear();

                    TableHeaderRow rno = new TableHeaderRow();
                    TableHeaderCell cellno = new TableHeaderCell();
                    cellno.ForeColor = System.Drawing.Color.Red;

                    if (dropdownlistDrug.SelectedIndex > 0)
                    {
                        cellno.Text = "No Opinions Found for the Drug -  " + dropdownlistDrug.SelectedItem.Text;

                    }
                    else
                    {
                        cellno.Text = "No Opinions Found";

                    }

                    rno.Controls.Add(cellno);
                    tableOpinions.Controls.Add(rno);
                }
            }
            catch
            {

            }
        }

        //event to delete medical practitioner
        void lbtn_delete_Click(object sender, EventArgs e)
        {
            BLL obj = new BLL();
            LinkButton lbtn = (LinkButton)sender;
            string[] s = lbtn.ID.ToString().Split('~');

            try
            {
                obj.DeleteOpinion(int.Parse(s[1]));

                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Opinion Deleted Successfully')</script>");
                LoadOpinions();

            }
            catch
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!!!')</script>");
            }
        }


    }
}