﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace drugs_symptoms_diseases.Admin
{
    public partial class ManageMP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["AdminId"] == null)
            {
                Session.Abandon();
                Response.Redirect("~/UserLogin.aspx");
            }
            else
            {
                if (!this.IsPostBack)

                    txtLoginId.Focus();

                LoadStaffs();
            }
        }

        //click event to upload new medical practitioner details
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BLL obj = new BLL();

            if (btnSubmit.Text.Equals("Submit"))
            {
                try
                {
                    if (obj.CheckLoginId(txtLoginId.Text))
                    {
                        obj.InsertUser(txtLoginId.Text, txtPassword.Text, txtEmailId.Text, "MedicalPractitioner");

                        //Emails.MailSender.SendEmail(" ", " ", txtEmailId.Value, "Credentials", "Login Id=" + txtLoginId.Value + "and Pwd=" + txtPassword.Value, " ");

                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('New User Added Successfully')</script>");
                        txtEmailId.Text = string.Empty;
                        txtPassword.Text = string.Empty;
                        txtLoginId.Text = string.Empty;
                        LoadStaffs();

                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('LoginId Exists!!!')</script>");
                    }
                }
                catch
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!')</script>");
                }
            }
            else if (btnSubmit.Text.Equals("Update"))
            {
                if (txtLoginId.Text.Equals(Session["loginId"].ToString()))
                {
                    try
                    {
                        obj.UpdateUser(txtLoginId.Text, txtPassword.Text, txtEmailId.Text, "MedicalPractitioner", Session["loginId"].ToString());

                        //Emails.MailSender.SendEmail(" ", " ", txtEmailId.Value, "Credentials", "User Id=" + txtUserId.Value + "and Pwd=" + txtPassword.Value, " ");

                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('User Updated Successfully')</script>");
                        txtEmailId.Text = string.Empty;
                        txtPassword.Text = string.Empty;
                        txtLoginId.Text = string.Empty;
                        LoadStaffs();

                        btnSubmit.Text = "Submit";

                    }
                    catch
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!')</script>");
                    }
                }
                else
                {
                    if (obj.CheckLoginId(txtLoginId.Text))
                    {
                        try
                        {
                            obj.UpdateUser(txtLoginId.Text, txtPassword.Text, txtEmailId.Text, "MedicalPractitioner", Session["loginId"].ToString());

                            //Emails.MailSender.SendEmail(" ", " ", txtEmailId.Value, "Credentials", "User Id=" + txtUserId.Value + "and Pwd=" + txtPassword.Value, " ");

                            ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('User Updated Successfully')</script>");
                            txtEmailId.Text = string.Empty;
                            txtPassword.Text = string.Empty;
                            txtLoginId.Text = string.Empty;
                            LoadStaffs();

                            btnSubmit.Text = "Submit";

                        }
                        catch
                        {
                            ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!')</script>");
                        }
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('LoginId Exists')</script>");
                    }
                }
            }
        }

        //function to load all medical practitioners
        private void LoadStaffs()
        {
            try
            {
                DataTable tab = new DataTable();
                BLL obj = new BLL();

                int serialNo = 1;

                tab = obj.GetUsersByType("MedicalPractitioner");

                if (tab.Rows.Count > 0)
                {
                    tableUsers.Rows.Clear();

                    tableUsers.BorderStyle = BorderStyle.Double;
                    tableUsers.GridLines = GridLines.Both;
                    tableUsers.BorderColor = System.Drawing.Color.Black;

                    TableRow mainrow = new TableRow();
                    mainrow.Height = 30;
                    mainrow.ForeColor = System.Drawing.Color.WhiteSmoke;
                    mainrow.Font.Bold = true;
                    mainrow.BackColor = System.Drawing.Color.DarkGreen;

                    TableCell cell1 = new TableCell();
                    cell1.Text = "<b>SL No</b>";
                    mainrow.Controls.Add(cell1);

                    TableCell cell2 = new TableCell();
                    cell2.Text = "<b>Login Id</b>";
                    mainrow.Controls.Add(cell2);

                    //TableCell cell3 = new TableCell();
                    //cell3.Text = "<b>Password</b>";
                    //mainrow.Controls.Add(cell3);

                    TableCell cell4 = new TableCell();
                    cell4.Text = "<b>EmailId</b>";
                    mainrow.Controls.Add(cell4);

                    TableCell cell5 = new TableCell();
                    cell5.Text = "<b>Edit</b>";
                    mainrow.Controls.Add(cell5);

                    TableCell cell6 = new TableCell();
                    cell6.Text = "<b>Delete</b>";
                    mainrow.Controls.Add(cell6);

                    tableUsers.Controls.Add(mainrow);

                    for (int i = 0; i < tab.Rows.Count; i++)
                    {
                        TableRow row = new TableRow();

                        TableCell cellSerialNo = new TableCell();
                        cellSerialNo.Width = 50;
                        cellSerialNo.Text = serialNo + i + ".";
                        row.Controls.Add(cellSerialNo);

                        TableCell cellUserId = new TableCell();
                        cellUserId.Width = 150;
                        cellUserId.Text = tab.Rows[i]["LoginId"].ToString();
                        row.Controls.Add(cellUserId);

                        //TableCell cellPassword = new TableCell();
                        //cellPassword.Width = 150;
                        //cellPassword.Text = tab.Rows[i]["Password"].ToString();
                        //row.Controls.Add(cellPassword);

                        TableCell cellEmailId = new TableCell();
                        cellEmailId.Width = 200;
                        cellEmailId.Text = tab.Rows[i]["EmailId"].ToString();
                        row.Controls.Add(cellEmailId);

                        TableCell cell_edit = new TableCell();
                        cell_edit.Width = 50;
                        LinkButton lbtn_edit = new LinkButton();
                        lbtn_edit.ForeColor = System.Drawing.Color.Red;
                        lbtn_edit.Text = "Edit";
                        lbtn_edit.ID = "Edit~" + tab.Rows[i]["LoginId"].ToString();
                        lbtn_edit.Click += new EventHandler(lbtn_edit_Click);
                        cell_edit.Controls.Add(lbtn_edit);
                        row.Controls.Add(cell_edit);

                        TableCell cell_delete = new TableCell();
                        cell_delete.Width = 50;
                        LinkButton lbtn_delete = new LinkButton();
                        lbtn_delete.ForeColor = System.Drawing.Color.Red;
                        lbtn_delete.Text = "Delete";

                        lbtn_delete.ID = "Delete~" + tab.Rows[i]["LoginId"].ToString();
                        lbtn_delete.OnClientClick = "return confirm('Are you sure want to delete this User?')";
                        lbtn_delete.Click += new EventHandler(lbtn_delete_Click);
                        cell_delete.Controls.Add(lbtn_delete);
                        row.Controls.Add(cell_delete);

                        tableUsers.Controls.Add(row);
                    }
                }
                else
                {
                    tableUsers.Rows.Clear();

                    TableHeaderRow rno = new TableHeaderRow();
                    TableHeaderCell cellno = new TableHeaderCell();
                    cellno.ForeColor = System.Drawing.Color.Red;
                    cellno.Text = "No Medical Practitioners Found";

                    rno.Controls.Add(cellno);
                    tableUsers.Controls.Add(rno);
                }
            }
            catch
            {

            }
        }

        //event to delete medical practitioner
        void lbtn_delete_Click(object sender, EventArgs e)
        {
            BLL obj = new BLL();
            LinkButton lbtn = (LinkButton)sender;
            string[] s = lbtn.ID.ToString().Split('~');

            try
            {
                obj.DeleteUser(s[1]);

                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('User Deleted Successfully')</script>");
                LoadStaffs();

            }
            catch
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!!!')</script>");
            }
        }

        //click event to edit the medical practitioner details
        void lbtn_edit_Click(object sender, EventArgs e)
        {
            try
            {
                BLL obj = new BLL();
                LinkButton lbtn = (LinkButton)sender;
                string[] s = lbtn.ID.ToString().Split('~');

                Session["loginId"] = null;
                Session["loginId"] = s[1];

                DataTable tab = new DataTable();
                tab = obj.GetUserByUserId(s[1]);

                if (tab.Rows.Count > 0)
                {
                    txtLoginId.Text = tab.Rows[0]["LoginId"].ToString();
                    txtPassword.Text = tab.Rows[0]["Password"].ToString();
                    txtEmailId.Text = tab.Rows[0]["EmailId"].ToString();
                }

                btnSubmit.Text = "Update";
            }
            catch
            {

            }
        }
        
    }
}