﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace drugs_symptoms_diseases.MedicalPractitioner
{
    public partial class SummarizationModule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            _Summarization();
        }
        
        //algorithm steps - lesk based algorithm
        private void _Summarization()
        {
            BLL obj = new BLL();

            DataTable tab = new DataTable();
            //scan the data (retrive the opinions from datatbase)
            tab = obj.GetAllOpinions();

            if (tab.Rows.Count > 0)
            {
                tableOpinions.Rows.Clear();

                tableOpinions.BorderStyle = BorderStyle.Double;
                tableOpinions.GridLines = GridLines.Both;
                tableOpinions.BorderColor = System.Drawing.Color.Black;

                TableRow mainrow = new TableRow();
                mainrow.HorizontalAlign = HorizontalAlign.Left;
                mainrow.Height = 30;
                mainrow.ForeColor = System.Drawing.Color.WhiteSmoke;
                mainrow.Font.Bold = true;
                mainrow.BackColor = System.Drawing.Color.DarkGreen;

                TableCell cell1 = new TableCell();
                cell1.Text = "<b>SL No</b>";
                mainrow.Controls.Add(cell1);

                TableCell cell2 = new TableCell();
                cell2.Text = "<b>Opinion</b>";
                mainrow.Controls.Add(cell2);

                TableCell cell3 = new TableCell();
                cell3.Text = "<b>Date</b>";
                mainrow.Controls.Add(cell3);

                TableCell cell4 = new TableCell();
                cell4.Text = "<b>Symptoms</b>";
                mainrow.Controls.Add(cell4);

                TableCell cell5 = new TableCell();
                cell5.Text = "<b>Diseases</b>";
                mainrow.Controls.Add(cell5);

                TableCell cell6 = new TableCell();
                cell6.Text = "<b>Drugs</b>";
                mainrow.Controls.Add(cell6);

                tableOpinions.Controls.Add(mainrow);

                int serialNo = 1;

                //each entry Oi[patient opinions] in buffer[storage server] do
                for (int i = 0; i < tab.Rows.Count; i++)
                {
                    TableRow row = new TableRow();
                    row.HorizontalAlign = HorizontalAlign.Left;
                    row.Height = 75;

                    TableCell cellSerialNo = new TableCell();
                    cellSerialNo.Width = 50;
                    cellSerialNo.Text = serialNo + i + ".";
                    row.Controls.Add(cellSerialNo);

                    TableCell cellOpinion = new TableCell();
                    cellOpinion.Width = 650;
                    cellOpinion.Text = tab.Rows[i]["Opinion"].ToString();
                    row.Controls.Add(cellOpinion);

                    TableCell cellDate = new TableCell();
                    cellDate.Width = 100;
                    cellDate.Text = tab.Rows[i]["PostedDate"].ToString();
                    row.Controls.Add(cellDate);

                    //code to remove the stop words [preprocessing of data]
                    //Tokenization [keyword extraction method – removing the stop words and retrieving the keywords]
                    string[] stopwords = { "a", "about", "above", "above", "across", "after", "afterwards", "again", "against", "all", "almost", "alone", "along", "already", "also", "although", "always", "am", "among", "amongst", "amoungst", "amount", "an", "and", "another", "any", "anyhow", "anyone", "anything", "anyway", "anywhere", "are", "around", "as", "at", "back", "be", "became", "because", "become", "becomes", "becoming", "been", "before", "beforehand", "behind", "being", "below", "beside", "besides", "between", "beyond", "bill", "both", "bottom", "but", "by", "call", "can", "cannot", "cant", "co", "con", "could", "couldnt", "cry", "de", "describe", "detail", "do", "done", "down", "due", "during", "each", "eg", "eight", "either", "eleven", "else", "elsewhere", "empty", "enough", "etc", "even", "ever", "every", "everyone", "everything", "everywhere", "except", "few", "fifteen", "fify", "fill", "find", "fire", "first", "five", "for", "former", "formerly", "forty", "found", "four", "from", "front", "full", "further", "get", "give", "go", "had", "has", "hasnt", "have", "he", "hence", "her", "here", "hereafter", "hereby", "herein", "hereupon", "hers", "herself", "him", "himself", "his", "how", "however", "hundred", "ie", "if", "in", "inc", "indeed", "interest", "into", "is", "it", "its", "itself", "keep", "last", "latter", "latterly", "least", "less", "ltd", "made", "many", "may", "me", "meanwhile", "might", "mill", "mine", "more", "moreover", "most", "mostly", "move", "much", "must", "my", "myself", "name", "namely", "neither", "never", "nevertheless", "next", "nine", "no", "nobody", "none", "noone", "nor", "not", "nothing", "now", "nowhere", "of", "off", "often", "on", "once", "one", "only", "onto", "or", "other", "others", "otherwise", "our", "ours", "ourselves", "out", "over", "own", "part", "per", "perhaps", "please", "put", "rather", "re", "same", "see", "seem", "seemed", "seeming", "seems", "serious", "several", "she", "should", "show", "side", "since", "sincere", "six", "sixty", "so", "some", "somehow", "someone", "something", "sometime", "sometimes", "somewhere", "still", "such", "system", "take", "ten", "than", "that", "the", "their", "them", "themselves", "then", "thence", "there", "thereafter", "thereby", "therefore", "therein", "thereupon", "these", "they", "thickv", "thin", "third", "this", "those", "though", "three", "through", "throughout", "thru", "thus", "to", "together", "too", "top", "toward", "towards", "twelve", "twenty", "two", "un", "under", "until", "up", "upon", "us", "very", "via", "was", "we", "well", "were", "what", "whatever", "when", "whence", "whenever", "where", "whereafter", "whereas", "whereby", "wherein", "whereupon", "wherever", "whether", "which", "while", "whither", "who", "whoever", "whole", "whom", "whose", "why", "will", "with", "within", "without", "would", "yet", "you", "your", "yours", "yourself", "yourselves", "the" };

                    string[] opinion = null;
                    opinion = tab.Rows[i]["Opinion"].ToString().Split(' ');
                    List<string> specialWords = new List<string>();

                    for (int y = 0; y < opinion.Length; y++)
                    {
                        opinion[y] = opinion[y].Replace(",", String.Empty);
                        opinion[y] = opinion[y].Replace(".", String.Empty);
                        opinion[y] = opinion[y].Replace("?", String.Empty);
                        opinion[y] = opinion[y].Replace(":", String.Empty);
                        opinion[y] = opinion[y].Replace("(", String.Empty);
                        opinion[y] = opinion[y].Replace(")", String.Empty);
                    }

                    for (int j = 0; j < opinion.Length; j++)
                    {
                        //Tokenization
                        if (!stopwords.Contains(opinion[j], StringComparer.InvariantCultureIgnoreCase))
                        {
                            specialWords.Add(opinion[j]);
                        }
                    }

                    //loading the keywords into string array
                    string[] Keywords = specialWords.ToArray();
                    string symptoms = null;
                    string diseases = null;
                    string drugs = null;


                    //keyword extraction technique                                        
                    DataTable tabSymptoms = new DataTable();
                    DataTable tabDiseases = new DataTable();
                    DataTable tabDrugs = new DataTable();


                    tabSymptoms = obj.GetKeywordsByType("Symptom");
                    tabDiseases = obj.GetKeywordsByType("Disease");
                    tabDrugs = obj.GetKeywordsByType("Drug");


                    //summarization - comparing with the wordnet (predefined dataset)
                    //Clustering the symptoms-diseases- drugs (grouping of similar objects)
                    for (int k = 0; k < tabSymptoms.Rows.Count; k++)
                    {
                        if (Keywords.Contains(tabSymptoms.Rows[k]["Keyword"].ToString(), StringComparer.InvariantCultureIgnoreCase))
                        {
                            symptoms += tabSymptoms.Rows[k]["Keyword"].ToString() + "<br/>";
                        }
                    }

                    if (symptoms == null)
                    {
                        TableCell cellSymptoms = new TableCell();
                        cellSymptoms.Width = 150;
                        cellSymptoms.Text = "No";
                        row.Controls.Add(cellSymptoms);
                    }
                    else
                    {
                        TableCell cellSymptoms = new TableCell();
                        cellSymptoms.Width = 150;
                        cellSymptoms.Text = symptoms;
                        row.Controls.Add(cellSymptoms);
                    }

                    //Clustering the symptoms-diseases- drugs (grouping of similar objects)
                    for (int k = 0; k < tabDiseases.Rows.Count; k++)
                    {
                        if (Keywords.Contains(tabDiseases.Rows[k]["Keyword"].ToString(), StringComparer.InvariantCultureIgnoreCase))
                        {
                            diseases += tabDiseases.Rows[k]["Keyword"].ToString() + "<br/>";
                        }
                    }

                    if (diseases == null)
                    {
                        TableCell cellDiseases = new TableCell();
                        cellDiseases.Width = 150;
                        cellDiseases.Text = "No";
                        row.Controls.Add(cellDiseases);
                    }
                    else
                    {
                        TableCell cellDiseases = new TableCell();
                        cellDiseases.Width = 150;
                        cellDiseases.Text = diseases;
                        row.Controls.Add(cellDiseases);
                    }

                    //Clustering the symptoms-diseases- drugs (grouping of similar objects)
                    for (int k = 0; k < tabDrugs.Rows.Count; k++)
                    {
                        if (Keywords.Contains(tabDrugs.Rows[k]["Keyword"].ToString(), StringComparer.InvariantCultureIgnoreCase))
                        {
                            drugs += tabDrugs.Rows[k]["Keyword"].ToString() + "<br/>";
                        }
                    }

                    if (drugs == null)
                    {
                        TableCell cellDrugs = new TableCell();
                        cellDrugs.Width = 150;
                        cellDrugs.Text = "No";
                        row.Controls.Add(cellDrugs);
                    }
                    else
                    {
                        TableCell cellDrugs = new TableCell();
                        cellDrugs.Width = 150;
                        cellDrugs.Text = drugs;
                        row.Controls.Add(cellDrugs);
                    }

                    tableOpinions.Controls.Add(row);
                }

            }
            else
            {
                tableOpinions.Rows.Clear();

                TableHeaderRow rno = new TableHeaderRow();
                TableHeaderCell cellno = new TableHeaderCell();
                cellno.ForeColor = System.Drawing.Color.Red;

                cellno.Text = "No Opinions Found";

                rno.Controls.Add(cellno);
                tableOpinions.Controls.Add(rno);
            }
        }

    }
}