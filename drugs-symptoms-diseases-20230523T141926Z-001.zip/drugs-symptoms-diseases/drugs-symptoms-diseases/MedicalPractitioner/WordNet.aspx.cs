﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace drugs_symptoms_diseases.MedicalPractitioner
{
    public partial class WordNet : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["MedicalPractitionerId"] == null)
            {
                Session.Abandon();
                Response.Redirect("~/UserLogin.aspx");
            }
            else
            {
                if (!this.IsPostBack)
                {
                    txtKeyword.Focus();
                    GetKeywords();
                }

                if (dropdownlistType.SelectedIndex > 0)
                {
                    GetKeywords();
                }
                else
                {
                    tableKeywords.Rows.Clear();

                    TableHeaderRow row = new TableHeaderRow();

                    TableCell cell = new TableCell();
                    cell.ColumnSpan = 10;
                    cell.ForeColor = System.Drawing.Color.Red;
                    cell.Font.Bold = true;
                    cell.Text = "No Keywords Found";
                    row.Controls.Add(cell);

                    tableKeywords.Controls.Add(row);
                }

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (dropdownlistType.SelectedIndex > 0)
            {
                BLL obj = new BLL();

                if (obj.CheckKeyword(txtKeyword.Text, dropdownlistType.SelectedValue))
                {
                    obj.InsertKeyword(txtKeyword.Text, dropdownlistType.SelectedValue);
                    Cleartextboxes();
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Keyword Inserted Successfully!!!')</script>");
                    dropdownlistType_SelectedIndexChanged(sender, e);
                    //GetKeywords();
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Keyword Exists!!!')</script>");
                }
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Select Type!!!')</script>");
            }
        }

        protected void dropdownlistType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropdownlistType.SelectedIndex > 0)
            {
                GetKeywords();
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Select Type!!!')</script>");
            }
        }

        private void GetKeywords()
        {
            DataTable tab = new DataTable();
            BLL obj = new BLL();
            int serialNo = 1;

            tab = obj.GetKeywordsByType(dropdownlistType.SelectedValue);

            if (tab.Rows.Count > 0)
            {
                tableKeywords.Rows.Clear();

                tableKeywords.BorderStyle = BorderStyle.Double;
                tableKeywords.GridLines = GridLines.Both;
                tableKeywords.BorderColor = System.Drawing.Color.Black;

                TableRow headerrow = new TableRow();
                headerrow.Height = 30;
                headerrow.ForeColor = System.Drawing.Color.WhiteSmoke;
                headerrow.BackColor = System.Drawing.Color.SteelBlue;

                TableCell cell1 = new TableCell();
                cell1.Text = "<b>SLNo</b>";
                headerrow.Controls.Add(cell1);

                //TableCell cell3 = new TableCell();
                //cell3.Text = "<b>Type</b>";
                //headerrow.Controls.Add(cell3);

                TableCell cell4 = new TableCell();
                cell4.Text = "<b>Keyword</b>";
                headerrow.Controls.Add(cell4);

                if (dropdownlistType.SelectedIndex > 0)
                {
                    TableCell cell7 = new TableCell();
                    cell7.Text = "<b>Delete</b>";
                    headerrow.Controls.Add(cell7);
                }
                else
                {

                }

                tableKeywords.Controls.Add(headerrow);

                for (int cnt = 0; cnt < tab.Rows.Count; cnt++)
                {
                    TableRow row = new TableRow();
                    row.Height = 30;

                    TableCell cellSerialNo = new TableCell();
                    cellSerialNo.Width = 10;
                    cellSerialNo.Font.Size = 10;
                    cellSerialNo.Text = serialNo + cnt + ".";
                    row.Controls.Add(cellSerialNo);

                    //TableCell cellType = new TableCell();
                    //cellType.Width = 150;
                    //cellType.Text = dropdownlistType.SelectedValue;
                    //row.Controls.Add(cellType);

                    TableCell cellKeyword = new TableCell();
                    cellKeyword.Width = 150;
                    cellKeyword.Text = tab.Rows[cnt]["Keyword"].ToString();
                    row.Controls.Add(cellKeyword);

                    if (dropdownlistType.SelectedIndex > 0)
                    {
                        TableCell cell_delete = new TableCell();
                        LinkButton lbtn_delete = new LinkButton();
                        lbtn_delete.ForeColor = System.Drawing.Color.Red;
                        lbtn_delete.Text = "Delete";

                        lbtn_delete.ID = tab.Rows[cnt]["KeywordId"].ToString();
                        lbtn_delete.OnClientClick = "return confirm('Are you sure want to delete this keyword?')";
                        lbtn_delete.Click += new EventHandler(lbtn_delete_Click);
                        cell_delete.Controls.Add(lbtn_delete);
                        row.Controls.Add(cell_delete);
                    }

                    tableKeywords.Controls.Add(row);
                }


            }
            else
            {
                tableKeywords.Rows.Clear();
                tableKeywords.BorderStyle = BorderStyle.None;
                tableKeywords.GridLines = GridLines.None;

                TableHeaderRow row = new TableHeaderRow();
                TableCell cell = new TableCell();
                cell.ColumnSpan = 10;
                cell.ForeColor = System.Drawing.Color.Red;
                cell.Font.Bold = true;
                cell.Text = "No Keywords Found";
                row.Controls.Add(cell);

                tableKeywords.Controls.Add(row);

            }
        }

        void lbtn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                LinkButton btn = (LinkButton)sender;

                BLL obj = new BLL();
                obj.DeleteKeyword(int.Parse(btn.ID.ToString()));

                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('Keyword Deleted Successfully!!!')</script>");
                GetKeywords();
                Cleartextboxes();
            }
            catch
            {
                ClientScript.RegisterStartupScript(this.GetType(), "key", "<script>alert('First Delete Related Attributes!!!')</script>");
            }
        }

        //function to clear the textboxes contents
        private void Cleartextboxes()
        {
            txtKeyword.Text = string.Empty;
            btnSubmit.Text = "Submit";
        }
    }
}