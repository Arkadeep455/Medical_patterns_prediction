﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace drugs_symptoms_diseases.MedicalPractitioner
{
    public partial class OpinionModule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["MedicalPractitionerId"] == null)
            {
                Session.Abandon();
                Response.Redirect("~/UserLogin.aspx");
            }
            else
            {
                if (!this.IsPostBack)
                {
                    txtName.Focus();
                    LoadDrugs();
                }

                LoadOpinions();
            }
        }

        //function to load all drugs
        private void LoadDrugs()
        {
            DataTable tab = new DataTable();
            BLL obj = new BLL();

            tab = obj.GetKeywordsByType("Drug");

            if (tab.Rows.Count > 0)
            {
                dropdownlistDrug.Items.Clear();

                dropdownlistDrug.DataSource = tab;
                dropdownlistDrug.DataTextField = "Keyword";
                dropdownlistDrug.DataValueField = "KeywordId";

                dropdownlistDrug.DataBind();

                dropdownlistDrug.Items.Insert(0, "All");

            }
            else
            {
                dropdownlistDrug.Items.Insert(0, "- Input Drugs-");

            }
        }

        //function to load all opinions (based on MP)
        private void LoadOpinions()
        {
            try
            {
                DataTable tab = new DataTable();
                BLL obj = new BLL();

                int serialNo = 1;

                if (dropdownlistDrug.SelectedIndex > 0)
                {
                    tab = obj.GetOpinionsByLoginIdandDrug(Session["MedicalPractitionerId"].ToString(), int.Parse(dropdownlistDrug.SelectedValue));
                   
                }
                else
                {
                    tab = obj.GetOpinionsByLoginId(Session["MedicalPractitionerId"].ToString());
                }

                if (tab.Rows.Count > 0)
                {
                    tableOpinions.Rows.Clear();

                    tableOpinions.BorderStyle = BorderStyle.Double;
                    tableOpinions.GridLines = GridLines.Both;
                    tableOpinions.BorderColor = System.Drawing.Color.Black;

                    TableRow mainrow = new TableRow();
                    mainrow.HorizontalAlign = HorizontalAlign.Left;
                    mainrow.Height = 30;
                    mainrow.ForeColor = System.Drawing.Color.WhiteSmoke;
                    mainrow.Font.Bold = true;
                    mainrow.BackColor = System.Drawing.Color.DarkGreen;

                    TableCell cell1 = new TableCell();
                    cell1.Text = "<b>SL No</b>";
                    mainrow.Controls.Add(cell1);

                    TableCell cell2 = new TableCell();
                    cell2.Text = "<b>Patient Name</b>";
                    mainrow.Controls.Add(cell2);
                                       
                    TableCell cell6 = new TableCell();
                    cell6.Text = "<b>Opinion</b>";
                    mainrow.Controls.Add(cell6);

                    TableCell cell7 = new TableCell();
                    cell7.Text = "<b>Date</b>";
                    mainrow.Controls.Add(cell7);

                    TableCell cell8 = new TableCell();
                    cell8.Text = "<b>Rating</b>";
                    mainrow.Controls.Add(cell8);

                    if (dropdownlistDrug.SelectedIndex > 0)
                    {
                        TableCell cell9 = new TableCell();
                        cell9.Text = "<b>Edit</b>";
                        mainrow.Controls.Add(cell9);

                        TableCell cell10 = new TableCell();
                        cell10.Text = "<b>Delete</b>";
                        mainrow.Controls.Add(cell10);
                    }

                    tableOpinions.Controls.Add(mainrow);

                    for (int i = 0; i < tab.Rows.Count; i++)
                    {
                        TableRow row = new TableRow();
                        row.HorizontalAlign = HorizontalAlign.Left;
                        row.Height = 75;

                        TableCell cellSerialNo = new TableCell();
                        cellSerialNo.Width = 50;
                        cellSerialNo.Text = serialNo + i + ".";
                        row.Controls.Add(cellSerialNo);

                        TableCell cellName = new TableCell();

                        string gender = null;
                        if (tab.Rows[i]["Gender"].ToString().Equals("True"))
                        {
                            gender = "Male";
                        }
                        else
                        {
                            gender = "Female";
                        }

                        cellName.Text = "<a href='#'>" + tab.Rows[i]["Name"].ToString() + "<span>Gender : " + gender + ".</br>Age : " + tab.Rows[i]["Age"].ToString() + ".</br>Address : " + tab.Rows[i]["Address"].ToString() + "</span></a>";
                        row.Controls.Add(cellName);                                    
                        
                        TableCell cellOpinion = new TableCell();
                        cellOpinion.Width = 700;
                        cellOpinion.Text = tab.Rows[i]["Opinion"].ToString();
                        row.Controls.Add(cellOpinion);

                        TableCell cellDate = new TableCell();
                        cellDate.Width = 100;
                        cellDate.Text = tab.Rows[i]["PostedDate"].ToString();
                        row.Controls.Add(cellDate);

                        TableCell cellRating = new TableCell();
                        cellRating.Width = 100;
                        cellRating.Text = tab.Rows[i]["Rating"].ToString();
                        row.Controls.Add(cellRating);

                        if (dropdownlistDrug.SelectedIndex > 0)
                        {

                            TableCell cell_edit = new TableCell();
                            cell_edit.Width = 50;
                            LinkButton lbtn_edit = new LinkButton();
                            lbtn_edit.ForeColor = System.Drawing.Color.Red;
                            lbtn_edit.Text = "Edit";
                            lbtn_edit.ID = "Edit~" + tab.Rows[i]["OpinionId"].ToString();
                            lbtn_edit.Click += new EventHandler(lbtn_edit_Click);
                            cell_edit.Controls.Add(lbtn_edit);
                            row.Controls.Add(cell_edit);

                            TableCell cell_delete = new TableCell();
                            cell_delete.Width = 50;
                            LinkButton lbtn_delete = new LinkButton();
                            lbtn_delete.ForeColor = System.Drawing.Color.Red;
                            lbtn_delete.Text = "Delete";

                            lbtn_delete.ID = "Delete~" + tab.Rows[i]["OpinionId"].ToString();
                            lbtn_delete.OnClientClick = "return confirm('Are you sure want to delete this Opinion?')";
                            lbtn_delete.Click += new EventHandler(lbtn_delete_Click);
                            cell_delete.Controls.Add(lbtn_delete);
                            row.Controls.Add(cell_delete);
                        }

                        tableOpinions.Controls.Add(row);
                    }
                }
                else
                {
                    tableOpinions.Rows.Clear();

                    TableHeaderRow rno = new TableHeaderRow();
                    TableHeaderCell cellno = new TableHeaderCell();
                    cellno.ForeColor = System.Drawing.Color.Red;

                    if (dropdownlistDrug.SelectedIndex > 0)
                    {
                        cellno.Text = "No Opinions Found for the Drug -  " + dropdownlistDrug.SelectedItem.Text;

                    }
                    else
                    {
                        cellno.Text = "No Opinions Found";

                    }
                   
                    rno.Controls.Add(cellno);
                    tableOpinions.Controls.Add(rno);
                }
            }
            catch
            {

            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BLL obj = new BLL();

            if (btnSubmit.Text.Equals("Submit"))
            {
                if (dropdownlistDrug.SelectedIndex > 0)
                {

                    bool flag = false;

                    if (dropdownlistType.SelectedIndex == 1)
                    {
                        flag = true;
                    }

                    obj.InsertOpinion(Session["MedicalPractitionerId"].ToString(), txtName.Text, int.Parse(txtAge.Text), txtAddress.Text, flag, int.Parse(dropdownlistDrug.SelectedValue), txtOpinion.Text, DateTime.Now, int.Parse(dropdownlistRating.SelectedItem.Text));

                    ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Opinion Added Successfully')</script>");
                    ClearTxts();
                    LoadOpinions();
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Select Drug')</script>");
                }

            }
            else if (btnSubmit.Text.Equals("Update"))
            {
                try
                {
                    if (dropdownlistDrug.SelectedIndex > 0)
                    {
                        bool flag = false;

                        if (dropdownlistType.SelectedIndex == 1)
                        {
                            flag = true;
                        }

                        obj.UpdateOpinion(Session["MedicalPractitionerId"].ToString(), txtName.Text, int.Parse(txtAge.Text), txtAddress.Text, flag, int.Parse(dropdownlistDrug.SelectedValue), txtOpinion.Text, DateTime.Now, int.Parse(dropdownlistRating.SelectedItem.Text), int.Parse(Session["opinionId"].ToString()));

                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Opinion Updated Successfully')</script>");

                        ClearTxts();
                        LoadOpinions();

                        btnSubmit.Text = "Submit";
                       // dropdownlistDrug_SelectedIndexChanged(sender, e);
                    }
                    else
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Select Drug')</script>");
                    }

                }
                catch
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!')</script>");
                }
            }
        }

        //event to delete medical practitioner
        void lbtn_delete_Click(object sender, EventArgs e)
        {
            BLL obj = new BLL();
            LinkButton lbtn = (LinkButton)sender;
            string[] s = lbtn.ID.ToString().Split('~');

            try
            {
                obj.DeleteOpinion(int.Parse(s[1]));

                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Opinion Deleted Successfully')</script>");
                LoadOpinions();

            }
            catch
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('Server Error!!!')</script>");
            }
        }

        //click event to edit the medical practitioner details
        void lbtn_edit_Click(object sender, EventArgs e)
        {
            try
            {
                BLL obj = new BLL();
                LinkButton lbtn = (LinkButton)sender;
                string[] s = lbtn.ID.ToString().Split('~');

                Session["opinionId"] = null;
                Session["opinionId"] = s[1];

                DataTable tab = new DataTable();
                tab = obj.GetOpinionById(int.Parse(s[1]));

                if (tab.Rows.Count > 0)
                {
                    txtAddress.Text = tab.Rows[0]["Address"].ToString();
                    txtAge.Text = tab.Rows[0]["Age"].ToString();
                    txtName.Text = tab.Rows[0]["Name"].ToString();
                    txtOpinion.Text = tab.Rows[0]["Opinion"].ToString();

                    string dataTextFieldDrug = dropdownlistDrug.Items.FindByValue(tab.Rows[0]["DrugId"].ToString()).ToString();

                    ListItem itemDrug = new ListItem(dataTextFieldDrug, tab.Rows[0]["DrugId"].ToString());
                    int indexDrug = dropdownlistDrug.Items.IndexOf(itemDrug);

                    if (indexDrug != -1)

                        dropdownlistDrug.SelectedIndex = indexDrug;

                    int index = 0;

                    if (tab.Rows[0]["Gender"].ToString().Equals("True"))

                        index = 1;

                    string dataTextFieldGender = dropdownlistType.Items.FindByValue(index.ToString()).ToString();

                    ListItem itemGender = new ListItem(dataTextFieldGender, index.ToString());
                    int indexGender = dropdownlistType.Items.IndexOf(itemGender);

                    if (indexGender != -1)

                        dropdownlistType.SelectedIndex = indexGender;

                    string dataTextFieldRating = dropdownlistRating.Items.FindByValue(tab.Rows[0]["Rating"].ToString()).ToString();

                    ListItem itemRating = new ListItem(dataTextFieldRating, tab.Rows[0]["Rating"].ToString());
                    int indexRating = dropdownlistRating.Items.IndexOf(itemRating);

                    if (indexRating != -1)

                        dropdownlistRating.SelectedIndex = indexRating;     
                }

                btnSubmit.Text = "Update";
            }
            catch
            {

            }
        }

        //function to clear the textbox contents
        private void ClearTxts()
        {
            txtAddress.Text = txtAge.Text = txtName.Text = txtOpinion.Text = string.Empty;
            dropdownlistRating.SelectedIndex = 0;
            dropdownlistType.SelectedIndex = 0;
        }

        protected void dropdownlistDrug_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadOpinions();
        }
        
    }
}